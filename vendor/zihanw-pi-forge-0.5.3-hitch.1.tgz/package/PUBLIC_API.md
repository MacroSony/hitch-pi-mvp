# Public API policy

The authoritative policy moved to [`docs/reference/public-api.md`](docs/reference/public-api.md).

This compatibility pointer remains at the published root path so existing links continue to work.


## Prompt-only embedding service (local 0.5.3-hitch.1)

`@zihanw/pi-forge/service` intentionally exposes `createForgeService` and
`reduceForgeTools`, with the corresponding `ForgeService*` types. Its named
consumer is Hitch Mode A. It accepts supplied Forge JSON documents and bounded
host-neutral runtime values; it does not load the desktop extension. See
[Mode A service](docs/mode-a-service.md) for the deliberately restricted subset.
This is a local integration prerelease, not an npm-published release.
