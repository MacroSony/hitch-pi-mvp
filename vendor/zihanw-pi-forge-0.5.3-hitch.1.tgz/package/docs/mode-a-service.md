# Mode A service entry

`@zihanw/pi-forge/service` is a narrow, read-only named-consumer entry for
Hitch's Mode A catalog. The caller supplies JSON documents for Forge-format
prompt stacks and agent profiles; Forge performs no workspace, global/home,
storage, project, plugin, extension, or provider discovery and does not write
anything.

The supported prompt subset is system-role blocks, static Forge variables or
parameters, and safe supplied-data slots (`date`, `tools`, `tool-guidelines`,
`active-model`, `cwd`, and an unmodified `chat-history` marker). `cwd` is always
virtual `/workspace`; Hitch supplies no host path. Pi retains its natural chat
history; history options and synthetic non-system blocks are rejected.

Regex, imports, skills, project context, append-prompt, custom slots/macros,
non-system blocks, unsafe profile fields, and project-scoped references are
rejected. Templates are checked with the existing `forge-v1` analyzer, and
resource policies use Forge's existing matcher without changing wildcard
boundaries. Errors are intentionally content-free and never contain source
paths or document text. The service snapshot is immutable; it is not the main
Forge extension entry point and does not alter Forge's UI or existing startup
behavior.

This worktree-only artifact is version `0.5.3-hitch.1`; it is intended for the
pinned local Hitch vendor tarball and is not published.
