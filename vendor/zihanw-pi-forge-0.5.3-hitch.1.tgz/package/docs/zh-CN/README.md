# pi-forge 中文文档

[项目首页](../../README.zh-CN.md) · [English docs](../README.md)

## 从这里开始

- [快速上手](getting-started.md)：安装、创建预设、打开编辑器并保存 Profile。
- [预设与堆栈](concepts/prompt-stacks.md)：完整预设及其有序 Block/Slot 编排。
- [Agent Profile](concepts/agent-profiles.md)：一次性模型/思考等级/预设组合。

## 指南

- [Web 编辑器](guides/web-editor.md)
- [迁移到 0.5](guides/migrating-to-0.5.md)
- [实验性前台 delegation](guides/delegation.md)：启用前请先阅读安全边界。
- [预设使用场景（英文）](../guides/use-cases.md)

自定义 macros/slots 和调试的完整说明目前以英文版为准：

- [Custom macros and slots](../guides/custom-macros-and-slots.md)
- [Prompt and payload debugging](../guides/debugging.md)

## 参考

- [命令参考](reference/commands.md)
- [Stack schema 与策略（英文）](../reference/stack-schema.md)
- [Macros 与 slots（英文）](../reference/macros-and-slots.md)
- [配置（英文）](../reference/configuration.md)
- [Public API（英文）](../reference/public-api.md)
- [实验性 subagent host port（英文）](../reference/subagent-host-port.md)

## 开发与设计

- [开发设置与兼容性（英文）](../development/setup.md)
- [Release 流程（英文）](../development/release.md)
- [Roadmap（英文）](../development/roadmap.md)
- [历史设计档案（英文）](../design/README.md)
