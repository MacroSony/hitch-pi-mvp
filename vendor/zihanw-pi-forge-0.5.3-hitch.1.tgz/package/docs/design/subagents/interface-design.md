# Subagent request/response design

Status: historical design and implementation record for the completed 0.4 path. Execution ownership (backend registry, preflight binding, plan sealing, conversation/execution fingerprints, lifecycle, and the fresh-process `pi-subprocess-readonly`/`pi-rpc-readonly` backends) lives in `@zihanw/pi-subagent-runtime`; the former in-package registry and `pi-sdk-isolated` compatibility backend were removed in that migration. The broader Pi SDK spike is recorded in the [SDK spike findings](sdk-spike-findings.md) (harness since removed), and the 0.5 boundary is documented in the [subagent host port contract](../../reference/subagent-host-port.md).

## Goals

- Make pi-forge profiles usable by native, subprocess, package-provided, or remote backends without requiring every backend to reproduce the parent Pi runtime.
- Start every subagent with a clean conversational context while allowing explicit, bounded context seeding.
- Keep prompt stacks as the profile-level source of prompt layout, visible-tool policy, and model-visible skills.
- Keep access, limits, cancellation, trace storage, and result reporting outside reusable profiles.
- Return a compact parent-visible tool result while retaining normalized execution history for authorized inspection.
- Export the demonstrated request/resolution/preflight/plan/response boundary while keeping a full owned runner, orchestration, and automatic delegation out of the package surface.

## Execution Flow

The portable caller request is not itself executable. Execution has five stages:

```text
AgentRequest
    -> host profile/stack/dependency resolution
    -> backend discovery and preflight
    -> backend-assisted host plan preparation
    -> backend execution
    -> AgentResponse
```

### 1. AgentRequest

The parent supplies intent: profile selection, task/media, explicit selected context, access requirements, limits, and parent-depth provenance. It does not contain parent runtime model objects, loaded files, credentials, raw session entries, or a compiled prompt.

### 2. Host resolution

pi-forge validates profile syntax, resolves the referenced prompt stack, identifies required custom macro/slot registrations, resolves selected parent-context references, and creates immutable declarative provenance. This stage does not claim that the target backend has the model, credentials, tools, isolation, or limit support needed to execute it.

Current parent-runtime resolution used by `/profile use` remains valid for applying profiles to the parent. Subagent host resolution must be a separate operation rather than reusing parent model/auth diagnostics as backend truth.

### 3. Backend discovery and preflight

Before prompt compilation, the selected backend reports:

- Model availability, authentication, thinking-level support, and media support.
- A stable tool catalog with backend tool IDs, policy-facing names, prompt snippets, and optional adapter mappings.
- Prompt-runtime inputs needed for Pi-compatible base prompts, tool guidance, skills, and context resources.
- Workspace/mount materialization support and granular access enforcement.
- Supported hard limits, cancellation behavior, trace support, and artifact behavior.
- Remote data-egress requirements.

The host applies the prompt stack's tool policy to the backend catalog. An allow pattern that matches nothing remains a warning unless separate dependency metadata marks that tool or capability as required.

### 4. Backend-assisted plan preparation and AgentExecutionPlan

The host combines the resolved profile, backend preflight receipt, selected context, and prompt-stack compiler into an immutable execution plan. The plan contains prepared system text/messages, exact model and thinking level, effective backend tool IDs, materialized workspace handles, enforced limits, diagnostics, provenance, and a stable execution fingerprint.

Some backends cannot expose exact prompt-runtime inputs during passive preflight. Pi SDK 0.80.6, for example, exposes its exact base prompt, tool snippets, skills, and context options through `before_agent_start`, immediately before provider execution. Such an adapter may supply those inputs to a trusted host preparation callback after accepting the prompt, provided it blocks provider transport until host compilation, protected-task validation, limit checks, and plan finalization succeed. A partial dry preflight must declare its prompt-runtime fidelity and cannot masquerade as the exact execution plan.

Custom macros and slots execute during plan preparation in the trusted host. Backends receive their rendered result and dependency receipt, not executable registration code. A raw `PromptStack` remains snapshot provenance and is not treated as an executable backend artifact.

For a null stack or append/prepend stack mode, the backend preflight must provide the base-prompt inputs required by the selected adapter. If the host cannot reproduce the intended base prompt, plan preparation fails.

### 5. AgentResponse

The backend returns normalized terminal status, output, enforcement receipts, effective tools/limits, artifacts, usage, and a routed trace handle. A separate projection determines what enters the parent model's context.

## Responsibility Boundaries

Effective permissions are the intersection of:

1. Profile prompt-stack tool selection.
2. Request access and limit requirements.
3. Backend-advertised capabilities and enforcement.

A backend must reject a required policy it cannot enforce. Prompt tool filtering is not a filesystem, process, or network sandbox.

pi-forge owns profile/stack resolution, trusted prompt compilation, context selection, plan creation, stable fingerprints, diagnostics, and parent-visible response projection. Backends own target-runtime preflight, execution, cancellation, backend-namespace canonicalization, enforcement receipts, usage collection, artifacts, and normalized traces.

## Context Model and Task Preservation

Subagents inherit no parent conversation automatically. Their prepared context contains:

1. System instructions compiled from the resolved profile and backend prompt inputs.
2. Optional parent-selected context rendered as quoted background evidence with provenance.
3. A protected final user task containing all request text and media.

Selected context may contain a provenance-bearing summary, visible user/assistant excerpts, quoted tool-result excerpts, and resource/artifact references. It never automatically contains the parent system prompt, full chat history, hidden reasoning, raw provider payloads, secrets, or environment variables.

Tool-result excerpts are background content, not native tool-result messages, because they do not have matching tool calls in the clean subagent history. Delimiters communicate instruction priority but are not a prompt-injection security boundary.

The delegated task is appended as a protected final user message after unrestricted prompt-stack message layout has been compiled. A backend adapter may combine adjacent user messages for provider compatibility, but it must preserve the delegated-context/task boundary and all structured media parts. Subagent preparation fails if the final normalized plan does not contain the complete task.

Context budgeting uses a required character/byte ceiling in v1. Any optional token estimate records the estimator/tokenizer name and version. Truncation removes optional context before required context and never truncates the final task or required media.

## Contract Artifacts

The TypeScript shapes and pure validators for the following artifacts are exported. Backend registration, explicit backend selection, and execution lifecycle are owned by `@zihanw/pi-subagent-runtime`; the extension composition root registers local `forge_subagent_profiles` discovery and drives the runtime's `pi-subprocess-readonly` (default) and `pi-rpc-readonly` backends for `forge_subagent` and `/forge-agent`.

### AgentRequest

- Schema version and host-generated request ID.
- Profile ID plus an optional expected source fingerprint for optimistic consistency.
- Structured text/media input.
- Optional selected-context summary/items with provenance and a character budget.
- Access requirements expressed through opaque workspace/resource handles, not backend-specific absolute paths.
- Hard execution limits and a separate parent-result projection limit.
- Parent run/session provenance and bounded delegation depth.
- Explicit remote-egress consent when a backend would transmit local project data.

### AgentProfileSnapshot

- Normalized profile fields and canonical source-profile digest.
- Normalized prompt-stack definition and canonical stack digest, or null.
- Required custom macro/slot dependency identities when available.
- No model-registry object, credential/auth result, loaded file path, diagnostics, session state, or secret.

This snapshot is immutable provenance. It is not sent to a backend as a promise that the profile is executable there.

### BackendPreflightResult

- Accepted/rejected state with structured diagnostics.
- Resolved target model and thinking level.
- Stable tool catalog and adapter mappings.
- Prompt-runtime/base-prompt inputs.
- Workspace materialization/mount mappings in the backend namespace.
- Granular enforcement capabilities and accepted hard limits.
- Media, cancellation, trace, artifact, and remote-egress behavior.

### AgentExecutionPlan

- Host-generated run ID, request ID, and backend ID.
- Prepared system prompt and normalized initial messages.
- Exact model, thinking level, effective backend tool IDs, and unmatched policy diagnostics.
- Materialized workspace handles, relative working directory, network policy, and enforcement requirements.
- Enforced execution limits and separate result-projection limits.
- Profile/stack provenance, dependency receipt, and backend preflight receipt.
- Canonical execution fingerprint covering all behavior-affecting prepared inputs.

The run ID exists before backend execution begins so cancellation and trace correlation do not depend on a remote backend first returning its own ID.

### AgentResponse

Response status is a discriminated union:

- `completed`: no error; output may be empty.
- `failed`: structured error required; optional partial output must be marked partial.
- `cancelled`: cancellation reason required; output is absent or explicitly partial.
- `timed-out`: timeout reason and enforced timeout required; output is absent or explicitly partial.
- `limit-reached`: the reached hard limit is required; output is absent or explicitly partial.

Every response includes request/run/backend correlation, model/profile/execution fingerprints, backend-produced enforcement receipt, effective tools and limits, duration, and artifact/trace routing metadata. `effectiveAccess` is never a request echo.

Token usage records tokenizer/model provenance when known. Cost uses an amount plus ISO currency code rather than an unqualified number. Artifact/change paths live in a named workspace namespace and include authorization, lifetime, and cleanup metadata.

Opaque backend trace IDs are registered behind host trace handles. Inspection authorizes the caller and routes through the backend/host trace registry. Hidden provider reasoning remains excluded by default.

Hard execution limits are distinct from response projection truncation. A backend that cannot enforce a required timeout, turn, token, output, filesystem, or network constraint rejects preflight.

## Access and Data-Egress Model

Requests identify host resources with opaque workspace/resource handles. Backend preflight maps them into backend-visible mounts or uploaded resources. The execution plan uses mount IDs plus normalized relative paths rather than assuming host absolute paths exist remotely.

- `none` permits no filesystem mounts and no filesystem working directory.
- `read-only` permits only read-only mounts.
- `workspace-write` permits explicitly identified read-write mounts; all other mounts remain read-only or absent.
- An access receipt distinguishes an `isolated` execution boundary from an explicitly unsafe `shared-user` process. At the shared-user boundary, access levels describe the model-visible tool policy rather than the child process's operating-system permissions.
- A working directory, when present, must be contained within an accepted mount.
- The backend canonicalizes and checks paths in its own namespace immediately before access and must enforce containment against symlink races.
- Model/provider transport is distinct from agent-accessible network tools.
- Sending project content to a remote backend requires an explicit egress decision; project trust alone is insufficient consent.

Capabilities are granular claims such as read-only mount isolation, read-write mount isolation, symlink-safe containment, agent-network isolation, timeout enforcement, turn enforcement, token-budget enforcement, output enforcement, cancellation, media transport, artifact retention, and trace inspection. Broad booleans are insufficient.

## Fingerprints and Compatibility

New portable fingerprints use canonical serialization and a named algorithm/version such as `sha256:v1:<digest>`.

- Source-profile fingerprint: normalized declarative profile.
- Prompt-stack fingerprint: normalized declarative stack.
- Execution fingerprint: compiled system/messages, exact model/thinking, effective tool IDs/mappings, relevant prompt-runtime inputs, selected-context/resource digests, dependency receipt, materialized access policy, enforced limits, and adapter/preflight version.

The existing `agentProfileFingerprint()` JSON string remains unchanged for stored branch provenance and drift compatibility. Portable snapshot/execution digests are new fields with separate semantics.

## Parent-Visible Result

The complete response is control-plane data. The main agent receives a bounded tool-result projection containing run ID, terminal status, output, and compact errors/warnings when applicable.

The human can expand the same tool result to inspect the plan summary, approval receipt, diagnostics, usage, normalized response, and complete captured subprocess transcript/tool events. Those details stay out of the normal model-visible projection. The full prepared prompt is shown only on demand before approval and is not persisted in result details by default. `/tree` changes the active conversation branch; it cannot undo provider egress, billing, or external effects. Contract trace inspection, artifacts, and resumable sessions remain separate and deferred.

## Revised Implementation Plan

### Integration checkpoint: require a user-visible walking skeleton

Fake-backend conformance proves contract and registry behavior, while the standalone SDK spike proved broader Pi provider behavior. The shipped walking skeleton sends a human-requested task through the complete profile-resolution, runtime-preflight, prompt-preparation, plan-validation, provider-execution, and response-projection path.

The first concrete integration was a pi-forge-owned `pi-sdk-isolated` adapter plus a human-operated plan/run command. The current integration drives the runtime package's foreground `pi-subprocess-readonly` (default) and `pi-rpc-readonly` backends for the command and model-callable tool. It exposes only stack-filtered read/list/search tools, declares a shared-user boundary rather than filesystem isolation, requires explicit approval of an immutable plan bound to runtime-issued fingerprints, and returns bounded output plus expandable reports.

This integration also exposed a contract seam hidden by the fake backend: backend-assisted preparation cannot require the caller to fabricate the prompt runtime that the backend is responsible for discovering. The backend must supply complete, canonical compiler inputs; the host must compile from them; and the registry must return the exact runtime/preparation pair used for execution-plan construction.

### Iteration 1: Shared profile service

- Extract shared typed profile repository operations for load, capture, save/update, and delete.
- Extract profile application and rollback from command rendering.
- Extract typed resolution preview and runtime/provenance drift status.
- Refactor commands to use the service without changing current CLI behavior.
- Add service-level tests so profile UI and subagent preparation share one implementation.

### Iteration 2: Internal real-backend spike (completed)

- Prototype one in-memory Pi SDK backend using a fresh `SessionManager`, explicit model/thinking, a controlled tool baseline, cancellation, and compact output.
- Exercise a real profile, restrictive prompt stack, custom macro/slot dependency, media input, and current local provider.
- Record actual SDK/runtime requirements and failure points.
- Keep all spike types internal and expose no run tool.

Implemented as the opt-in `scripts/subagent-sdk-spike.ts` (removed in the 0.4 cleanup after its findings were productized in the runtime's shared preparation gate); results and limitations are recorded in `SUBAGENT_SDK_SPIKE_FINDINGS.md`.

### Iteration 3: Resolve/preflight/plan boundary (completed)

- Split parent application resolution from backend-independent host resolution.
- Define internal request, backend descriptor/preflight, backend-assisted preparation callback, execution-plan, response, enforcement-receipt, and diagnostic types based on the spike.
- Implement protected task/context preparation and tool negotiation.
- Validate null/replace/append/prepend stacks and missing custom dependencies.

Implemented in `src/subagent-host.ts` and focused modules under `src/subagent/`, with `src/subagent-contract.ts` retained as a compatibility barrel. The SDK spike consumes the shared protected-task and host-resolution helpers.

### Iteration 4: Stable validation and fingerprints (completed)

- Add canonical snapshot/stack/execution digests without changing legacy provenance fingerprints.
- Add pure validators and the full status/error/access/limit matrices.
- Add deterministic context budgeting and artifact/trace namespace validation.
- Export only the portions demonstrated by the real spike.

Implemented with canonical `sha256:v1` fingerprints, deterministic UTF-8 context budgeting, access/limit/status matrices, artifact/trace validation, and package-root exports. Legacy profile provenance fingerprints are unchanged.

### Iteration 5: Backend registration and conformance (completed)

- Added an optional backend registry/dispatcher with validated descriptor discovery and granular capability negotiation.
- Added a deterministic fake backend and reusable conformance fixtures shaped by the real spike.
- Normalized cancellation races, host-abort timeouts, provider failures, malformed responses, enforcement receipts, and authorization-scoped trace routing.
- pi-forge remains fully functional with no registered backend; the registry starts empty.

### Iteration 6: Concrete Pi SDK walking skeleton (completed)

- Correct backend-assisted prompt-runtime ownership and add complete compiler-input validation/fingerprints.
- Extract an access-none, no-tool, in-memory Pi SDK backend from the completed spike.
- Add human-operated backend discovery, dry plan, and explicit real-run commands through the registry.
- Cover pre-transport refusal, provider failure, host timeout, cancellation, response normalization, and cleanup without live provider calls in ordinary tests.

Implemented as the exported experimental `PiSdkIsolatedBackend` and `/forge-agent backends|plan|run` command path. Ordinary tests use Pi's faux provider through a real in-memory `AgentSession`, proving provider gating and final context without network traffic.

### Iteration 7: Foreground parent integration (completed)

- Added no-egress `forge_subagent_profiles` discovery so the main agent can select only from profile IDs explicitly enabled by trusted-project delegation policy rather than guessing.
- Added the sequential `forge_subagent` tool on the shared command/runtime path rather than creating a second runner.
- Added project-only `subagents.profiles.<id>` policy so ordinary profiles remain portable and independently usable while delegation eligibility, backend, and timeout are resolved per profile; global config remains limited to general defaults until global profile and stack storage have explicit scope semantics.
- Resolve the profile and prepare the exact immutable plan before asking for interactive approval or permitting provider transport.
- Show a compact default review, with full prompt inspection on demand, and bind approval to the execution fingerprint.
- Insert only bounded response text into parent context while retaining complete transcript/tool-event details for expanded human inspection.
- Keep execution text-only, foreground, clean-context, read-only, and shared-user; cancellation, rejection, provider failure, and missing-UI cases fail closed.

### Iteration 8: Sandbox and staged-write decision

- Evaluate an optional bubblewrap-style backend that can honestly enforce allowed roots, network policy, and subprocess restrictions without changing the portable contract.
- Design writes as a separately approved staged patch/change set with clear inspection and undo semantics; do not simply add `write`, `edit`, or shell to the shared-user child.
- Continue deferring resumable agents, retries, queues, chains, pipelines, background work, and concurrency orchestration until concrete demand exists.

Profile UI can proceed independently on the completed Iteration 1 service; it does not need to block parent integration or a concrete adapter decision. Each iteration remains independently reviewable and revertible.

## Deferred Decisions

- Whether the experimental Pi SDK backend remains built in, becomes separately configurable, or moves to an optional integration after 0.4 feedback.
- Trace/artifact storage location, retention defaults, redaction, and cleanup implementation.
- Resumable sessions and continuation references.
- Automatic retries, fallbacks, priorities, queues, and concurrency.
- Secret/environment injection.
- Structured JSON-schema output.
- Automatic parent-context selection beyond explicit summaries and references.
